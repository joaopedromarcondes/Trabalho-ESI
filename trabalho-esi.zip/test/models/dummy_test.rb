# test/models/dummy_test.rb
require "test_helper"

class DummyTest < ActiveSupport::TestCase
  test "simple true" do
    assert true
  end
end
