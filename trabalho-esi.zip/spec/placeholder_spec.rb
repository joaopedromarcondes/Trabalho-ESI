require 'rails_helper'

RSpec.describe "CI Pipeline" do
  it "confirms that tests are running" do
    expect(true).to be(true)
  end
end