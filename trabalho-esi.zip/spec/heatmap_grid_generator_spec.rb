RSpec.describe HeatmapGridGenerator do
  it "agrupa medições em células de grid e calcula média" do
    NoiseMeasurement.create!(latitude: -23.5611, longitude: -46.6568, level: 70)
    NoiseMeasurement.create!(latitude: -23.5612, longitude: -46.6567, level: 90)

    result = HeatmapGridGenerator.new(resolution: 0.01).generate

    expect(result).to be_a(Array)
    expect(result.first[:level]).to eq(80) # média de 70 + 90
  end
end
