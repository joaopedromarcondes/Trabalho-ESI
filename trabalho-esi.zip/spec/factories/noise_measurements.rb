FactoryBot.define do
  factory :noise_measurement do
    latitude { 1.5 }
    longitude { 1.5 }
    level { 1 }
  end
end
