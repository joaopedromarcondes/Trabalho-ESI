FactoryBot.define do
  factory :health_symptom do
    sintoma { "Febre" }
    intensidade { :alto }
  end
end
