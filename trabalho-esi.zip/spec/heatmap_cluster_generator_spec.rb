RSpec.describe HeatmapClusterGenerator do
  it "gera clusters de medições" do
    NoiseMeasurement.create!(latitude: -23.56, longitude: -46.65, level: 70)
    NoiseMeasurement.create!(latitude: -23.57, longitude: -46.66, level: 80)

    result = HeatmapClusterGenerator.new.generate

    expect(result).to be_a(Array)
    expect(result.first).to include(:latitude, :longitude, :level)
  end
end
