class NoiseMeasurement < ApplicationRecord
    # possui latitude, longitude e level (em dB)
end
