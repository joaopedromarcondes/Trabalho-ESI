class EngagementNotifier
  def self.run_daily
    raise NotImplementedError, "Implementar envio de notificações de engajamento"
  end
end
