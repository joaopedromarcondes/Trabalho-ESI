require 'factory_bot'

World(FactoryBot::Syntax::Methods)

# If you use DatabaseCleaner / transactions, ensure factories create persisted records.
